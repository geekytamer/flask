from flask_wtf import FlaskForm
from flask_wtf.file import FileField, FileAllowed
from wtforms import StringField, PasswordField, MultipleFileField , FileField, SubmitField, TextAreaField, SelectField, IntegerField
from wtforms.validators import DataRequired, Email, EqualTo
from wtforms import ValidationError

class NewFileForm(FlaskForm):
    files = MultipleFileField('File(s) Upload', validators=[FileAllowed(['jpg','png', 'jpeg'])])
    submit = SubmitField('submit')
    title  = StringField("Title: ")
    context = TextAreaField("Context: ")
    post_type = SelectField("type of news: ", choices = [('news','news'), ('fyp',"fyp") , ('ws','workshop') , ('ad',"advertisement")])
    
class newPicForm(FlaskForm):
    files = MultipleFileField('File(s) Upload', validators=[FileAllowed(['jpg','png', 'jpeg'])])
    post_id = SelectField("post id: ", choices = [])
    submit = SubmitField('submit')
    
class contactForm(FlaskForm):
    name = StringField("الاسم ")
    email = StringField("البريد الإلكتروني ")
    subject = StringField("العنوان")
    context = TextAreaField("المحتوى")
    submit = SubmitField("إرسال")
    
    
    