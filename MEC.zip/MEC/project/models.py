from project import db
from datetime import datetime

class news(db.Model):
    __tablename__ = 'news'
    
    
    title = db.Column(db.String(128), primary_key = True,unique = True, index = True)
    context = db.Column(db.String)
    submission_date = db.Column(db.DateTime)
    pictures = db.relationship("pictures", backref = 'news', lazy = 'dynamic')
    news_type = db.Column(db.String)
    def __init__(self, title, context, news_type):
        
        self.title = title
        self.submission_date = datetime.now()
        self.context = context
        
        self.news_type = news_type
    
    def __repr__(self):
        return f"title:{self.title} date: {self.submission_date}"
        

    
    

class pictures(db.Model):
    __tablename__ = 'pictures'
    id = db.Column(db.Integer,primary_key = True)
    post_id = db.Column(db.String(128), db.ForeignKey('news.title'))
    title = db.Column(db.String(128), unique = True, index = True)
    def __init__(self, post_id, title):
        self.post_id = post_id
        self.title = title
        
class honors(db.Model):
    __tablename__ = 'honors'
    squ_id = db.Column(db.Integer, primary_key = True)
    grade = db.Column(db.Float)
    cohort = db.Column(db.String(4))
    name = db.Column(db.String)
    def __init__(self, squ_id, grade, cohort, name):
        self.cohort=cohort
        self.grade= grade
        self.name = name
        self.squ_id = squ_id
    
    def __repr__(self):
        return f"Student {self.name} from cohort {self.cohort} with grade {self.grade}"
    
    