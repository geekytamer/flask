from project import app,db, mail
import os
import secrets

from project.forms import NewFileForm, newPicForm, contactForm
from project.models import news, pictures
import yagmail
from flask_admin import Admin, BaseView, expose
from flask_mail import Message
from flask_admin.contrib.sqla import ModelView
from flask import render_template, request, redirect, flash, url_for, flash
from werkzeug.utils import secure_filename

class pic_view(BaseView):
    
    @expose('/', methods=("POST","GET"))
    def upload(self):
        form = newPicForm()
        form.post_id.choices = [(news.title, news.title) for news in news.query]
        if form.validate_on_submit():
            objs = []
            
            
            for picture in form.files.data:
                #self.upload_file()
             #   print(file)
                random_hex = secrets.token_hex(8)
                _, f_ext = os.path.splitext(picture.filename)
                picture_fn = random_hex + f_ext 
                picture_path = os.path.join(app.root_path, 'static/uploads', picture_fn)
                pic = pictures(form.post_id.data, picture_fn)
                objs.append(pic)
                picture.save(picture_path)
            
                
            
            db.session.add_all(objs)
            db.session.commit()
            return self.render('admin/picForm.html', form=form)
        return self.render('admin/picForm.html', form=form)

class NewView(BaseView):
    
    @expose('/', methods=("POST","GET"))
    def upload(self):
        form = NewFileForm()
        if form.validate_on_submit():
            objs = []
            post = news(form.title.data,form.context.data,form.post_type.data)
            
            
            for picture in form.files.data:
                #self.upload_file()
             #   print(file)
                random_hex = secrets.token_hex(8)
                _, f_ext = os.path.splitext(picture.filename)
                picture_fn = random_hex + f_ext 
                picture_path = os.path.join(app.root_path, 'static/uploads', picture_fn)
                pic = pictures(post.title, picture_fn)
                objs.append(pic)
                picture.save(picture_path)
            
                
            db.session.add(post)
            db.session.add_all(objs)
            db.session.commit()
            return self.render('admin/addOwner.html', form=form)
        return self.render('admin/addOwner.html', form=form)
    
    
@app.route("/")
def index():
    news_list = news.query.order_by(news.submission_date).limit(3).all()
    return render_template("index.html" ,news_list = news_list)   

@app.route("/الأخبار")
def newsfunc():
    news_list = news.query.order_by(news.submission_date)
    return render_template("news.html" ,news_list = news_list)   

@app.route("/المجلة/<post_title>")
def newspost(post_title):
    new_post = news.query.filter(news.title == post_title).first()
    return render_template("post.html", new_post = new_post)
    
@app.route("/تواصل معنا", methods=["GET", 'POST'])
def contact():
    form = contactForm()
    if form.validate_on_submit():
        with app.app_context():  
            msg = Message(subject=f"Hello {form.name.data}",
                        sender=app.config.get("MAIL_USERNAME"),
                        recipients=[form.email.data], # replace with your email for testing
                        body=f"This is a email I sent with Gmail and Python to confirm that we reseved your email about {form.subject.data} and thank you for reaching us!!")
            mail.send(msg)
            
            return render_template("contactus.html" , form = form)
    return render_template("contactus.html" , form = form)

def send_mail():
    msg = Message(request.form['subject'], recipients=['tamer.abbasher@gmail.com'])
    msg.sender(request.form['name'], request.form['email'])
    msg.body(request.form['message'])
    mail.ssend(msg)
    return redirect(url_for(contact))
admin = Admin(app)
admin.add_view(ModelView( news, db.session))
admin.add_view(ModelView(pictures, db.session))
admin.add_view(NewView( name = "add_news", endpoint = "addOwner"))
admin.add_view(pic_view(name = "add_pics", endpoint="picForm"))

if __name__ == "__main__":
    
        
    app.run(debug=True)
    
    
